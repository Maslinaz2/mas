-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июн 18 2025 г., 09:47
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `danshindemo`
--

-- --------------------------------------------------------

--
-- Структура таблицы `________________`
--

CREATE TABLE `________________` (
  `Категория` varchar(14) DEFAULT NULL,
  `Марка` varchar(22) DEFAULT NULL,
  `Номерной знак` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `________________`
--

INSERT INTO `________________` (`Категория`, `Марка`, `Номерной знак`) VALUES
('На каждый день', 'Geely Coolray Flagship', 'м324ст797'),
('На каждый день', 'Geely Coolray Flagship', 'е434ка797'),
('На каждый день', 'Geely Coolray Flagship', 'у831ое77'),
('На каждый день', 'Renault Duster', 'с452оо77'),
('На каждый день', 'Renault Duster', 'м674то97'),
('На каждый день', 'Renault Duster', 'е592оу777'),
('На каждый день', 'Renault Duster', 'о553вс797'),
('На каждый день', 'Volkswagen Polo 6', 'о444ту197'),
('На каждый день', 'Volkswagen Polo 6', 'с591ут97'),
('На каждый день', 'Volkswagen Polo 6', 'в667см97'),
('На каждый день', 'Volkswagen Polo 6', 'в569оо777'),
('На каждый день', 'Volkswagen Polo 6', 'с231оо797'),
('На каждый день', 'Volkswagen Polo 6', 'в583ее77'),
('Праздник', 'Mercedes E200', 'о454вс77'),
('Праздник', 'Mercedes E200', 'е982то97'),
('Праздник', 'Mercedes E200', 'е337ео777'),
('Праздник', 'Mercedes C180', 'о123оу777'),
('Праздник', 'Mercedes C180', 'о093оо97'),
('Праздник', 'Audi A6', 'е772ое777'),
('Груз и шаттл', 'Ford Transit', 'о438вм97'),
('Груз и шаттл', 'Ford Transit', 'о127ум97'),
('Груз и шаттл', 'Peugeot Expert', 'в673со77'),
('Молния', 'Электрокар Nissan Leaf', 'е654аа777'),
('Молния', 'Электрокар Nissan Leaf', 'а676ут797'),
('Жара', 'Jeep Sahara', 'т444от777');

-- --------------------------------------------------------

--
-- Структура таблицы `________________________________`
--

CREATE TABLE `________________________________` (
  `Категория` varchar(14) DEFAULT NULL,
  `Марка` varchar(22) DEFAULT NULL,
  `Номерной знак` varchar(9) DEFAULT NULL,
  `Пробег` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Дамп данных таблицы `________________________________`
--

INSERT INTO `________________________________` (`Категория`, `Марка`, `Номерной знак`, `Пробег`) VALUES
('На каждый день', 'Geely Coolray Flagship', 'м324ст797', '34578,0'),
('На каждый день', 'Geely Coolray Flagship', 'е434ка797', '45718,0'),
('На каждый день', 'Geely Coolray Flagship', 'у831ое77', '56122,0'),
('На каждый день', 'Renault Duster', 'с452оо77', '178567,0'),
('На каждый день', 'Renault Duster', 'м674то97', '12478,0'),
('На каждый день', 'Renault Duster', 'е592оу777', '126789,0'),
('На каждый день', 'Renault Duster', 'о553вс797', '45890,0'),
('На каждый день', 'Volkswagen Polo 6', 'о444ту197', '78121,0'),
('На каждый день', 'Volkswagen Polo 6', 'с591ут97', '56477,0'),
('На каждый день', 'Volkswagen Polo 6', 'в667см97', '23045,0'),
('На каждый день', 'Volkswagen Polo 6', 'в569оо777', '40784,0'),
('На каждый день', 'Volkswagen Polo 6', 'с231оо797', '112089,0'),
('На каждый день', 'Volkswagen Polo 6', 'в583ее77', '89014,0'),
('Праздник', 'Mercedes E200', 'о454вс77', '14875,0'),
('Праздник', 'Mercedes E200', 'е982то97', '15277,0'),
('Праздник', 'Mercedes E200', 'е337ео777', '89457,0'),
('Праздник', 'Mercedes C180', 'о123оу777', '38457,0'),
('Праздник', 'Mercedes C180', 'о093оо97', '103784,0'),
('Праздник', 'Audi A6', 'е772ое777', '124561,0'),
('Груз и шаттл', 'Ford Transit', 'о438вм97', '82467,0'),
('Груз и шаттл', 'Ford Transit', 'о127ум97', '98453,0'),
('Груз и шаттл', 'Peugeot Expert', 'в673со77', '123811,0'),
('Молния', 'Электрокар Nissan Leaf', 'е654аа777', '68124,0'),
('Молния', 'Электрокар Nissan Leaf', 'а676ут797', '36489,0'),
('Жара', 'Jeep Sahara', 'т444от777', '55012,0'),
('', '', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
